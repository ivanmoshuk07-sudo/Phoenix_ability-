-- StandaloneNames: original v0.8.5 abilities/DBM logic, frame placement only.
-- Previous friendly-name renderer is intentionally not loaded.
local A = {defaults={}}
StandaloneNames = A
local function fill(dst,defaults)
    for key,value in pairs(defaults) do
        if type(value)=='table' then
            if type(dst[key])~='table' then dst[key]={} end
            fill(dst[key],value)
        elseif dst[key]==nil then dst[key]=value end
    end
end
A.Fill=fill
function A:Say(message)
    DEFAULT_CHAT_FRAME:AddMessage('|cff66ccffStandalone Names|r: '..tostring(message))
end
