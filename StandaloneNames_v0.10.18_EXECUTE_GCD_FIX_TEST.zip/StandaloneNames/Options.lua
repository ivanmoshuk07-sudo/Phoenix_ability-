-- Only the two requested modules. Their option definitions are from v0.8.5.
local E=ElvUI[1]
local A=StandaloneNames
function A:InsertOptions()
    E.Options.args.standaloneNames={
        type='group',name='Standalone Names',order=80,childGroups='tab',
        args={
            description={type='description',order=1,
                name='ДБМ и Способности — отдельные панели: ElvUI → Перенос рамок. ' ..
                     'Настройки способностей и их логика сохранены из v0.8.5.'}
        }
    }
    local args=E.Options.args.standaloneNames.args
    if self.InsertDBMOptions then self:InsertDBMOptions(args) end
    if self.InsertAbilityOptions then self:InsertAbilityOptions(args) end
end
function A:OpenOptions()
    if InCombatLockdown() then self:Say('Откройте настройки после боя.'); return end
    E:ToggleOptionsUI('standaloneNames')
end
SLASH_STANDALONENAMES1='/snames'
SlashCmdList.STANDALONENAMES=function() A:OpenOptions() end
