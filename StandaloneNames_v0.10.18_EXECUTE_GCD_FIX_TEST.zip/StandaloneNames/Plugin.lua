-- Original ElvUI profile path and module initialization order retained.
local addonName=...
local E,L,V,P=unpack(ElvUI)
local A=StandaloneNames
local M=E:NewModule('StandaloneNamesPlugin')
local function copy(t)
    local out={}
    for k,v in pairs(t) do out[k]=type(v)=='table' and copy(v) or v end
    return out
end
P.standaloneNames=copy(A.defaults)
function M:BindProfile()
    if type(E.db.standaloneNames)~='table' then E.db.standaloneNames={} end
    A.db=E.db.standaloneNames
    A.Fill(A.db,A.defaults)
    if A.Abilities and A.Abilities.PrepareProfiles then A.Abilities:PrepareProfiles() end
    if A.DBM then A.DBM:Apply() end
    if A.Abilities then A.Abilities:Apply() end
    if A.RefreshAbilityOptions then A.RefreshAbilityOptions() end
end
function M:Initialize()
    if self.initialized then return end
    self.initialized=true
    if type(StandaloneNamesDB)~='table' then StandaloneNamesDB={} end
    A.state=StandaloneNamesDB
    self:BindProfile()
    if A.DBM then A.DBM:Initialize() end
    if A.Abilities then A.Abilities:Initialize() end
    E.Libs.EP:RegisterPlugin(addonName,function() A:InsertOptions() end)
    hooksecurefunc(E,'UpdateAll',function() M:BindProfile() end)
end
E:RegisterModule(M:GetName(),function() M:Initialize() end)
